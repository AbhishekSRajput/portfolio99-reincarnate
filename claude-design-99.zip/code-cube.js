// <code-cube> — 3x3x3 lattice, three.js, scroll-linked rotation. Attributes: theme="light|dark", motion="full|calm"
customElements.define('code-cube', class extends HTMLElement {
  static get observedAttributes() { return ['theme', 'motion']; }

  connectedCallback() {
    if (this._booted) return;
    this._booted = true;
    const root = this.attachShadow({ mode: 'open' });
    root.innerHTML = '<style>:host{display:block;width:100%;height:100%}canvas{display:block;width:100%;height:100%}</style>';
    this._canvas = document.createElement('canvas');
    root.appendChild(this._canvas);
    this._boot();
  }

  disconnectedCallback() {
    cancelAnimationFrame(this._frame);
    window.removeEventListener('scroll', this._onScroll);
    if (this._ro) this._ro.disconnect();
    if (this._renderer) this._renderer.dispose();
  }

  attributeChangedCallback() { this._applyTheme(); }

  palette() {
    const dark = this.getAttribute('theme') === 'dark';
    return dark
      ? { line: 0x6c6559, lineHi: 0xf1ede3, accent: 0xd97a4e }
      : { line: 0xb9b1a0, lineHi: 0x17150f, accent: 0xa8401f };
  }

  _applyTheme() {
    if (!this._mats) return;
    const p = this.palette();
    this._mats.line.color.setHex(p.line);
    this._mats.lineHi.color.setHex(p.lineHi);
    this._mats.accent.color.setHex(p.accent);
  }

  async _boot() {
    let THREE;
    try {
      THREE = await import('https://unpkg.com/three@0.160.0/build/three.module.js');
    } catch (e) { return; }

    const p = this.palette();
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(28, 1, 0.1, 100);
    camera.position.set(0, 0, 12.5);

    const renderer = new THREE.WebGLRenderer({ canvas: this._canvas, alpha: true, antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this._renderer = renderer;

    const mats = {
      line: new THREE.LineBasicMaterial({ color: p.line, transparent: true, opacity: 0.85 }),
      lineHi: new THREE.LineBasicMaterial({ color: p.lineHi }),
      accent: new THREE.MeshBasicMaterial({ color: p.accent, transparent: true, opacity: 0.16 })
    };
    this._mats = mats;

    const group = new THREE.Group();
    const step = 1.24, size = 1.0;
    const box = new THREE.BoxGeometry(size, size, size);
    const edges = new THREE.EdgesGeometry(box);

    for (let x = -1; x <= 1; x++) {
      for (let y = -1; y <= 1; y++) {
        for (let z = -1; z <= 1; z++) {
          const shell = Math.abs(x) + Math.abs(y) + Math.abs(z);
          if (shell === 0) continue; // hollow centre
          const outer = shell === 3;
          const line = new THREE.LineSegments(edges, outer ? mats.lineHi : mats.line);
          line.position.set(x * step, y * step, z * step);
          group.add(line);
          if (x === 1 && y === 1 && z === 1) {
            const solid = new THREE.Mesh(box, mats.accent);
            solid.position.copy(line.position);
            group.add(solid);
          }
        }
      }
    }
    scene.add(group);

    const resize = () => {
      const w = this.clientWidth || 300, h = this.clientHeight || 300;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    resize();
    this._ro = new ResizeObserver(resize);
    this._ro.observe(this);

    let target = 0, eased = 0;
    this._onScroll = () => {
      const max = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
      target = Math.min(1, (window.scrollY || 0) / max);
    };
    window.addEventListener('scroll', this._onScroll, { passive: true });
    this._onScroll();

    const calm = () => this.getAttribute('motion') === 'calm' ||
      (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

    const start = performance.now();
    const tick = () => {
      const t = (performance.now() - start) / 1000;
      eased += (target - eased) * 0.06;
      const drift = calm() ? 0 : t * 0.11;
      group.rotation.y = -0.62 + drift + eased * 1.5;
      group.rotation.x = -0.32 + (calm() ? 0 : Math.sin(t * 0.22) * 0.06) + eased * 0.35;
      renderer.render(scene, camera);
      this._frame = requestAnimationFrame(tick);
    };
    tick();
  }
});
