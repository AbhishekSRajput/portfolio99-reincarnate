// <gear-train> — three meshing extruded gears, three.js, scroll-driven. Attributes: theme, motion
customElements.define('gear-train', class extends HTMLElement {
  static get observedAttributes() { return ['theme', 'motion']; }

  connectedCallback() {
    if (this._booted) return;
    this._booted = true;
    const root = this.attachShadow({ mode: 'open' });
    root.innerHTML = '<style>:host{display:block;width:100%;height:100%}canvas{display:block;width:100%;height:100%}</style>';
    this._canvas = document.createElement('canvas');
    root.appendChild(this._canvas);
    this._boot();
  }

  disconnectedCallback() {
    cancelAnimationFrame(this._frame);
    if (this._ro) this._ro.disconnect();
    if (this._renderer) this._renderer.dispose();
  }

  attributeChangedCallback() { this._applyTheme(); }

  palette() {
    const dark = this.getAttribute('theme') === 'dark';
    return dark
      ? { steel: 0xbdb5a6, accent: 0xd97a4e, key: 0xffffff, fill: 0x4a453a, ground: 0x14130f }
      : { steel: 0x413a30, accent: 0xa8401f, key: 0xfff8ec, fill: 0xb9b1a0, ground: 0xf4f1ea };
  }

  _applyTheme() {
    if (!this._mats) return;
    const p = this.palette();
    this._mats.steel.color.setHex(p.steel);
    this._mats.accent.color.setHex(p.accent);
    if (this._lights) {
      this._lights.key.color.setHex(p.key);
      this._lights.hemi.color.setHex(p.key);
      this._lights.hemi.groundColor.setHex(p.fill);
    }
  }

  _gearGeometry(THREE, teeth, mod, depth) {
    const pitch = (mod * teeth) / 2;
    const ro = pitch + mod * 0.86;
    const ri = pitch - mod * 0.72;
    const step = (Math.PI * 2) / teeth;
    const shape = new THREE.Shape();
    const pt = (r, a) => [Math.cos(a) * r, Math.sin(a) * r];
    for (let i = 0; i < teeth; i++) {
      const a = i * step;
      const t = step * 0.5;
      const pts = [
        pt(ri, a - t * 0.66), pt(ro, a - t * 0.30),
        pt(ro, a + t * 0.30), pt(ri, a + t * 0.66)
      ];
      pts.forEach((p, j) => {
        if (i === 0 && j === 0) shape.moveTo(p[0], p[1]);
        else shape.lineTo(p[0], p[1]);
      });
    }
    shape.closePath();

    const hub = new THREE.Path();
    hub.absarc(0, 0, pitch * 0.26, 0, Math.PI * 2, true);
    shape.holes.push(hub);

    if (teeth >= 18) {
      const holes = 5, hr = pitch * 0.16;
      for (let i = 0; i < holes; i++) {
        const a = (i / holes) * Math.PI * 2 + 0.3;
        const p = new THREE.Path();
        p.absarc(Math.cos(a) * pitch * 0.58, Math.sin(a) * pitch * 0.58, hr, 0, Math.PI * 2, true);
        shape.holes.push(p);
      }
    }

    return new THREE.ExtrudeGeometry(shape, {
      depth, bevelEnabled: true, bevelThickness: mod * 0.16, bevelSize: mod * 0.16, bevelSegments: 2, curveSegments: 12
    });
  }

  async _boot() {
    let THREE;
    try { THREE = await import('https://unpkg.com/three@0.160.0/build/three.module.js'); }
    catch (e) { return; }

    const p = this.palette();
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(26, 1.4, 0.1, 100);

    const renderer = new THREE.WebGLRenderer({ canvas: this._canvas, alpha: true, antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this._renderer = renderer;

    const mats = {
      steel: new THREE.MeshStandardMaterial({ color: p.steel, roughness: 0.42, metalness: 0.32 }),
      accent: new THREE.MeshStandardMaterial({ color: p.accent, roughness: 0.38, metalness: 0.3 })
    };
    this._mats = mats;

    const hemi = new THREE.HemisphereLight(p.key, p.fill, 0.85);
    const key = new THREE.DirectionalLight(p.key, 1.9);
    key.position.set(-3, 5, 7);
    const rim = new THREE.DirectionalLight(0xffffff, 0.5);
    rim.position.set(5, -2, -4);
    scene.add(hemi, key, rim);
    this._lights = { hemi, key };

    const mod = 0.17, depth = 0.38;
    const specs = [
      { teeth: 26, mat: mats.steel, dir: -1 },
      { teeth: 15, mat: mats.accent, dir: 1 },
      { teeth: 11, mat: mats.steel, dir: -1 }
    ];
    const gears = [];
    const group = new THREE.Group();
    let cx = 0, cy = 0, prev = null;
    const angles = [-0.52, -0.62];

    specs.forEach((s, i) => {
      const pitch = (mod * s.teeth) / 2;
      if (prev) {
        const d = prev.pitch + pitch;
        const a = angles[i - 1];
        cx += Math.cos(a) * d;
        cy += Math.sin(a) * d;
      }
      const geo = this._gearGeometry(THREE, s.teeth, mod, depth);
      const mesh = new THREE.Mesh(geo, s.mat);
      mesh.position.set(cx, cy, -depth / 2 + (i === 1 ? 0.06 : 0));
      group.add(mesh);
      gears.push({ mesh, teeth: s.teeth, dir: s.dir });
      prev = { pitch };
    });

    // centre the train, tilt it slightly so the extrusion reads
    const box = new THREE.Box3().setFromObject(group);
    const c = box.getCenter(new THREE.Vector3());
    group.position.set(-c.x, -c.y, 0);
    const wrap = new THREE.Group();
    wrap.add(group);
    wrap.rotation.set(-0.46, 0.52, 0.05);
    scene.add(wrap);

    const span = Math.max(box.getSize(new THREE.Vector3()).x, 1);
    camera.position.set(0, -0.15, span * 2.1);
    camera.lookAt(0, 0, 0);

    const resize = () => {
      const w = this.clientWidth || 360, h = this.clientHeight || 300;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    resize();
    this._ro = new ResizeObserver(resize);
    this._ro.observe(this);

    const calm = () => this.getAttribute('motion') === 'calm' ||
      (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

    let eased = 0;
    const base = gears[0].teeth;
    const start = performance.now();
    const tick = () => {
      const target = calm() ? 0 : (window.scrollY || 0) * 0.0042;
      eased += (target - eased) * 0.075;
      const drift = calm() ? 0 : (performance.now() - start) / 1000 * 0.06;
      gears.forEach(g => {
        g.mesh.rotation.z = g.dir * (eased + drift) * (base / g.teeth) + (g.dir > 0 ? Math.PI / g.teeth : 0);
      });
      renderer.render(scene, camera);
      this._frame = requestAnimationFrame(tick);
    };
    tick();
  }
});
